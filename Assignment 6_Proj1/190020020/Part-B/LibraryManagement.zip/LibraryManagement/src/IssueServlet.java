

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class IssueServlet
 */
@WebServlet("/IssueServlet")
public class IssueServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IssueServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{
	
		//getting input values from jsp page
		int student_id = Integer.parseInt(request.getParameter("student_id")); 
		int book_id = Integer.parseInt(request.getParameter("book_id"));  
		String issue_date = request.getParameter("issue_date");
		String return_date = request.getParameter("return_date");


		Connection con = null;
 		String url = "jdbc:mysql://localhost:3306/Library"; //MySQL URL and followed by the database name
 		String username = "universityDB0020"; //MySQL username
 		String password = "Root@lab4"; //MySQL password
		
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(url, username, password); //attempting to connect to MySQL database
 		System.out.println("Printing connection object "+con);
 		
 		//checking if a student exists
 		PreparedStatement st=con.prepareStatement("select * from student where student_id=?");
 		st.setInt(1, student_id);
 		ResultSet student_count=st.executeQuery();
 		int count_student=0;
 		while(student_count.next()) {
			count_student=count_student+1;
		}
 		if(count_student>0) {
 			//if book with given id is not present, add it
 			PreparedStatement st2=con.prepareStatement("insert into issue values(?, ?, ?, ?)");
 			st2.setString(1,Integer.toString(student_id));
 			st2.setString(2,Integer.toString(book_id));
 			st2.setString(3, issue_date);
 			st2.setString(4, return_date);
 			int result=st2.executeUpdate();
 			//Checks if insert is successful.If yes,then redirects to IssueResult.jsp page 
 			if(result>0)
 			{
 				
 				RequestDispatcher rd = request.getRequestDispatcher("IssueResult.jsp");
 				rd.forward(request, response);
 			}
 			
 		}
 		else {
 			//don't issue a book
 			System.out.println("Student does not exist");
 		}

		}
		 catch (Exception e) 
 		{
 			e.printStackTrace();
 		}
	}

}
